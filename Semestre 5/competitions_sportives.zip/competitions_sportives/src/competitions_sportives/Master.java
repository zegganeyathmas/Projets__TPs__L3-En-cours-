package competitions_sportives;

import java.util.*;

import competitions_sportives.strategies.AbstractPoule;
import competitions_sportives.strategies.AbstractSelection;
import competitions_sportives.util.*;

public class Master extends Competition{
	
	private AbstractSelection s;
	private AbstractPoule p;
	
	private Tournament tournament;
	private League league;
	private List<League> leagues;
	
	

	/**
	 * constructor
	 * @param competitors a GroupStage
	 * @param selection the selection we want to choose to unroll the master class
	 */
	public Master(List<Competitor> competitors , AbstractSelection selection, AbstractPoule p) {
		super(competitors);
		this.s=selection;
		this.p=p;
		this.leagues = new ArrayList<>();
	}

	/**
	 * this method manages the progress of the Master
	 * @param competitors the list of competitors
	 */
	public void play(List<Competitor> competitors) throws NotPowerOfTwoException{
		this.display("\n *** Début du Master ***");
		List<List<Competitor>> created = this.createPoules(competitors, s.getNbPoules()); 
		List<List<Competitor>> executed = this.executePoules(created); // exécution
		List<Competitor> qualifies = s.selectCompetitors(executed); // sélection
		this.display("\nLes compétiteurs qualifiés à la phase finale sont : \n"+qualifies);
		this.display("\n*** Phase finale : ***");
		this.phaseFinale(qualifies); // le tournoi
	}
	
	/**
	 * returns a competitor map ranked in ascending point order
	 * @return a competitor map ranked in ascending point order
	 */ 
	public Map<Competitor,Integer> ranking2() {
		Map<Competitor,Integer> map = new HashMap<>();
		for(League l : this.leagues) {
			for(Competitor c : l.getCompetitors()) {
				if(!this.tournament.getCompetitors().contains(c)) {
					map.put(c, c.getNbPoints());
				}
				else {
					int index = tournament.getCompetitors().indexOf(c);
					c.addPoints(tournament.getCompetitors().get(index).getNbPoints());
					map.put(c,c.getNbPoints());
				}
			}
		}
		map=MapUtil.sortByDescendingValue(map);
		return map;
	}
	
	/**
	 * this method allows us to create the different hens of our master class
	 * @param competitors list of our competitors
	 * @param nbPoules number of hens to create 
	 * @return a list contains the hens of our competitions, each hen is represented as a list
	 */
	public List<List<Competitor>> createPoules(List<Competitor> competitors, int nbPoules) {
		List<List<Competitor>> created = new ArrayList<>();
		Poule poule = new Poule(competitors, nbPoules, p); 
		created = poule.getPoulesBeforeLeague();
		return created;
	}
	
	/**
	 * this method allows us to execute our first step of our master class "league"
	 * @param poules a list contains the hens of our master class after being created, each hen is represented as a list
	 * @return a list contains the hens of our master class after being executed and sorting by descending values 
	 */
	public List<List<Competitor>> executePoules(List<List<Competitor>> poules) {
		Map<Competitor, Integer> map = new HashMap<Competitor, Integer>();
		int i = 1;
		List<List<Competitor>> poulesRanked = new ArrayList<>();
		this.display("\n*** Phase de poules du master: ***");
		for (List<Competitor> poule : poules) {
			this.league = new League(poule);
			this.leagues.add(this.league);
			this.display("\n*** Poule : " +i+" ***\n");
			this.league.play(poule);
			map = this.league.ranking();
			this.league.displayRankedMap(map,"Poule "+ i);
			i++;
			List<Competitor> l = new ArrayList<>();
			for (Competitor c : map.keySet()) {
				l.add(c);
			}
			poulesRanked.add(l);
		}
		return poulesRanked;
	}
	
	/**
	 * this method allows us to run the tournament phase of our master class
	 * @param l a list of the competitors qualified from the league phase
	 * @return a list of our qualified from the league phase after playing the tournament sorting by descending values
	 */
	public List<Competitor> phaseFinale(List<Competitor> l) {
		Map<Competitor, Integer> map = new HashMap<Competitor, Integer>();
		List<Competitor> tournamentList = new ArrayList<>();
		// le tournoi des qualifiés des leagues se joue indépendemment des points 
		for(Competitor c : l) {
			tournamentList.add(new Competitor(c.getName()));
		}
		this.display("\n *** Phase finale du master ***\n");
		try {
			this.tournament = new Tournament(tournamentList);
			tournament.play(tournamentList);
			
		}catch(NotPowerOfTwoException e) {
			this.display("The number of competitors is not power of two, so the tournament cannot be played in this master.\n");
		}
		for(Competitor c : tournament.getCompetitors()) {
			map.put(c, c.getNbPoints());
		}
		map = MapUtil.sortByDescendingValue(map);
		tournament.displayRankedMap(map,"tournament");
		
		/*tournamentList après le tri décroissant des points*/
		List<Competitor> tries = new ArrayList<>();
		for(Competitor c : map.keySet()) {
			tries.add(c);
		}
		return tries;
	}
	
	/**
	 * returns the selection we want to choose to unroll the master class
	 * @return the selection we want to choose to unroll the master class
	 */
	public AbstractSelection getSelection() {
		return this.s;
	}
	
	/**
	 * this method returns the list of group stage of our master class
	 * @return the list of group stage of our master class
	 */
	public List<League> getLeagues() {
		return leagues;
	}
	
	/**
	 * this method returns the tournament run in our master class
	 * @return the tournament run in our master class
	 */
	public Tournament getTournament() {
		return tournament;
	}
	/**
	 * display the Winner of the Master
	 */
	public void displayWinner() {
		System.out.println("**** **** ****\n The winner of the Master is : "+Tournament.WINNER+".\n**** **** ****\n");
	}
	
	/**
	 * display a message
	 * @param msg the message to display
	 */
	public void display(String msg) {
		System.out.println(msg);
	}
	

}
