package competitions_sportives;

import java.util.*;


/**
 * @author yathmas
 * @author yasser
 *
 */
public class Competitor {

	private String name;
	private int nbPoints;
	private int cote;

	
	/**
	 * this method changes the odds of a competitor 
	 * @param cote odds of a competitor
	 */
	public void setCote(int cote) {
		this.cote += cote;
	}

	/**
	 * this method return the odds of a competitor
	 * @return the odds of a competitor
	 */
	public int getCote() {
		return cote;
	}
	
	/**
	 * constructor
	 * @param name the name of the competitor
	 */
	public Competitor(String name) {
		this.name=name;
		this.nbPoints=0;
		this.cote = 0;
	}
	
	/**
	 * returns name of competitor
	 * @return name of competitor
	 */
	public String getName() {
		return name;
	}

	/**
	 * returns the number of points of a competitor
	 * @return the number of points of a competitor
	 */
	public int getNbPoints() {
		return nbPoints;
	}

	/**
	 * this method change number of points of a competitor
	 * @param nbPoints the new number of points of a competitors
	 */
	public void addPoints( int nbPoints) {
		this.nbPoints = this.nbPoints + nbPoints;
	}
	
	/**
	 * this method returns the points of a competitor to 0
	 */
	public void initialPoints( ) {
		this.nbPoints = 0;
	}
	
	
	
	
	
	/**
	 * returns true if another object is "equal to" this one "obj" false otherwise.
	 * @param obj to compare with
	 * @return  true if another object is "equal to" this one "obj" false otherwise.
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Competitor other = (Competitor) obj;
		return Objects.equals(name, other.name);
	}
	
	
	/**
	 *returns the name of competitor 
	 *@return the name of competitor
	 */
	@Override
	public String toString() {
		return this.getName();
	}
	
}
