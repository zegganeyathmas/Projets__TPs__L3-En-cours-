package competitions_sportives.observable;

import competitions_sportives.Competitor;

public class Cote implements MatchListener {
	
	/**
	 * this method allows us to display the winner of the match as well as the odds of the 2 competitors in the match
	 * @param ce the competition on which we will react
	 */
	public void reactToMatch(CompetitionsEvent ce) {
		Competitor c1 = ce.getMatch().getC1();
		Competitor c2 = ce.getMatch().getC2();
		Competitor gagnant = ce.getMatch().getWinner();
		
		if(gagnant.equals(c1)) {
			System.out.println("-->Bookmaker : Victoire de "+c1.getName()+"(cote "+c1.getCote()+") face à "+c2.getName()+"(cote "+c2.getCote()+").");
			gagnant.setCote(-1);
			c2.setCote(1);
			System.out.println(">La cote de "+c1.getName()+" passe à "+c1.getCote()+", celle de "+c2.getName()+" à "+c2.getCote()+"\n");
		}
		else {
			System.out.println("-->Bookmaker : Victoire de "+c2.getName()+"(cote "+c2.getCote()+") face à "+c1.getName()+"(cote "+c1.getCote()+").");
			gagnant.setCote(-1);
			c1.setCote(1);
			System.out.println(">La cote de "+c2.getName()+" passe à "+c2.getCote()+", celle de "+c1.getName()+" à "+c1.getCote()+"\n");
		}
		
		
	}
}
