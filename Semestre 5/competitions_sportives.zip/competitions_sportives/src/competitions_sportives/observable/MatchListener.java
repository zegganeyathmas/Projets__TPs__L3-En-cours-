package competitions_sportives.observable;

import java.util.EventListener;

public interface MatchListener extends EventListener {
	
	public void reactToMatch(CompetitionsEvent ce);
	
}
