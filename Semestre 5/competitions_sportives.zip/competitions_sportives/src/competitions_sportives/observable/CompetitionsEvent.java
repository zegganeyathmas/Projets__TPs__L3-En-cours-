package competitions_sportives.observable;

import java.util.EventObject;

import competitions_sportives.Match;

public class CompetitionsEvent extends EventObject {
	
	private Match match;
	
	/**
	 * Constructor
	 * @param m match of the competition
	 */
	public CompetitionsEvent(Match m) {
		super(m);
		this.match = m;
	}
	
	/**
	 * this method return a match of the competition
	 * @return a match of the competition
	 */
	public Match getMatch() {
		return match;
	}
	
}
