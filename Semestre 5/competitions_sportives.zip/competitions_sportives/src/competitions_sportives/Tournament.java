package competitions_sportives;

import java.util.*; 
import competitions_sportives.util.NotPowerOfTwoException;

public class Tournament extends Competition {
	
	public static Competitor WINNER;
	
	/**
	 * return the winner of the tournament
	 * @return the winner of the tournament
	 */
	public static Competitor getWINNER() {
		return WINNER;
	}

	/**
	 * constructor
	 * @param competitors list of competitors in the tournament
	 */
	public Tournament(List<Competitor> competitors) {
		super(competitors);
	}
	
	/**
	 * this method manages the progress of the tournament
	 * @param competitors the list of competitors
	 */
	public void play(List<Competitor> competitors) throws NotPowerOfTwoException{
		if(! Tournament.isPowerOfTwo(competitors.size())) {
			throw new NotPowerOfTwoException("The number of competitors is not power of two, so the tournament cannot be played.\n");
		} 
		Collections.shuffle(competitors);
		List<Competitor> winners = new ArrayList<>();
		boolean finished = false;
		Competitor c = null ;
		int i = 0;
		//System.out.println("\n*******Phase 1 de Tournament*******");
		while(!finished) {
			c = this.playMatch(competitors.get(i),competitors.get(i+1));
			winners.add(c);
			i+=2;
			i = i % (competitors.size());
			if (i==0) {
				//System.out.println("\n*******Phase 2 de Tournament*******");
				while(winners.size()>1) {
					c = this.playMatch(winners.get(i),winners.get(i+1));
					if(winners.get(i).equals(c)) {
						winners.remove(i+1);
		
					}
					else {
						winners.remove(i);
					}
					i++;
					i = i % winners.size();
				}
				
				finished=true;
			}
		}
		Tournament.WINNER = c ;
	}
	
	
	/**
	 * Returns true if x represents power of two and false if not
	 * @param x integer 
	 * @return true if x represents power of two and false if not
	 */
	public static final boolean isPowerOfTwo(int x) {
		return (x > 0) && (x & (x-1)) == 0;
	}
	
	
	/**
	 * this method display the winner of this tournament
	 */
	public void displayWinner() {
		System.out.println("**** **** ****\n The winner of the tournament is : "+Tournament.WINNER+" with "+Tournament.WINNER.getCote()+" cotes.\n**** **** ****");
	}
	
	
	
}
