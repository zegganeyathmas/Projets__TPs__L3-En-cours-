package competitions_sportives.util;

public class NotPowerOfTwoException extends RuntimeException {
	public NotPowerOfTwoException(String msg) {
		super(msg);
	}
	

}
