package competitions_sportives.util;

public class NumberOfCompetitorsNotExpected extends RuntimeException {
	
	public NumberOfCompetitorsNotExpected(String msg) {
		super(msg);
	}
}
