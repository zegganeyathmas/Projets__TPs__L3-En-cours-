package competitions_sportives;

import java.util.*;

import competitions_sportives.strategies.*;

public class Poule {
	
	private List<List<Competitor>> poulesBeforeLeague;

	/**
	 * Constructor
	 * @param competitors a list of competitors
	 * @param nbPoules number of hens 
	 * @param apoule an object of our class Abstractpoule
	 */
	public Poule(List<Competitor> competitors, int nbPoules, AbstractPoule apoule) {
		this.poulesBeforeLeague = apoule.partition(competitors, nbPoules);
	}
	
	/**
	 * return a list of our hens.
	 * @return list of our hens.
	 */
	public List<List<Competitor>> getPoulesBeforeLeague() {
		return poulesBeforeLeague;
	}

	
}
