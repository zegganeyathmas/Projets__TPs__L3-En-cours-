package competitions_sportives;

import java.util.*;

public class Match {
	
	private Competitor c1;
	private Competitor c2; 
	private Competitor winner;

	/**
	 * constructor
	 * @param c1 first competitor
	 * @param c2 second competitor
	 */
	
	public Match(Competitor c1, Competitor c2){
		this.c1 = c1;
		this.c2 = c2;
	}
	  
	/**
	 * returns the winner between the two competitors a and b
	 * @param c1 first competitor
	 * @param c2 second competitor
	 * @return the winner between the two competitors c1 and c2
	 */
	public Competitor winnerOfTheMatch(Competitor c1, Competitor c2) {
		Random random = new Random();
		int alea = random.nextInt(2);
		if (alea == 0) {
			this.winner = c1;
			return c1;
		}
		else {
			this.winner = c2;
			return c2;
		} 
	}   
	
	
	/**
	 * this method display the winner of the match 
	 * @param a the first competitor
	 * @param b the second competitor 
	 * @param w the winner between the two competitors a and b
	 */
	public void displayWinnerOfTheMatch(Competitor a, Competitor b,Competitor w) {
			System.out.println(a.getName()+" vs "+b.getName()+" ---> "+w.getName()+" wins !");
	}
	
	/**
	 * returns the first competitor c1 of the match
	 * @return the first competitor c1 of the match
	 */
	public Competitor getC1() {
		return c1;
	} 

	/**
	 * returns the second competitor c2 of the match
	 * @return the second competitor c2 of the match
	 */
	public Competitor getC2() {
		return c2;
	}
	
	/**
	 * returns the winner of the match
	 * @return the winner of the match
	 */
	public Competitor getWinner() {
		return this.winner;
	}

}    
