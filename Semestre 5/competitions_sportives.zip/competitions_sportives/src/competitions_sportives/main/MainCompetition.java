package competitions_sportives.main;


import java.util.*;

import competitions_sportives.*;
import competitions_sportives.strategies.*;
import competitions_sportives.util.*;

public class MainCompetition {

	private static Master master;

	public static void main(String[] args) {
		
		List<Competitor> competitors = new ArrayList<>();
		League league = new League(competitors);
		Tournament tournament = new Tournament(competitors);
		AbstractSelection selection = null;
		AbstractPoule apoule = null;
		master = null;
		
		Scanner sc = new Scanner(System.in);
		System.out.println("\n\nChoisissez ce que vous voulez jouer :\nl : jouer league\nt : jouer le tournoi\nm : jouer le master");
		String s = sc.nextLine();
		
		
		if(args.length == 0) 
		 {
			System.out.println("\n*****\nLes compétiteurs sont donc choisis par défaut (Il y'en a 8 par défaut.)\nSi vous voulez saisir vos compétiteurs, veuillez les préciser sur la ligne de commande.\n*****\n");
			Competitor Brazil = new Competitor("Brazil");
			Competitor France = new Competitor("France");
			Competitor Argentine = new Competitor("Argentine");
			Competitor italie = new Competitor("italie");
			Competitor Algerie = new Competitor("Algerie");
			Competitor Maroc = new Competitor("Maroc");
			Competitor Espagne = new Competitor("Espagne");
			Competitor Portugal = new Competitor("Portugal");
			competitors.add(Brazil);
			competitors.add(France); 
			competitors.add(Argentine);
			competitors.add(italie);
			competitors.add(Algerie);
			competitors.add(Maroc);
			competitors.add(Espagne);
			competitors.add(Portugal);	
		}
		for(String arg : args) {
			competitors.add(new Competitor(arg));
		}
			 
		System.out.println("Competitors are : \n"+competitors+"\n");
		if(s.equals("l")) {
			league.play();
		}
		else if (s.equals("t")) {
			try {
				tournament.play();
			}catch(NotPowerOfTwoException e) {
				System.out.println("The number of competitors is not power of two, so the tournament cannot be played.\n");
			}
				
		}
		else if(s.equals("m")) {
			System.out.println("Choisissez le nombre des Poules :  ");
			int nbrPoules = sc.nextInt();
			System.out.println("Choisissez le nombre de compétiteurs de chaque poule :  ");
			int nbrPlayers = sc.nextInt();
			System.out.println("Choisissez le processus de création de poules :  \n"
							+ "1 : OneByOne (remplit les poules une par une par les compétiteurs donnés.)\n");
			int processusPoule = sc.nextInt();
			if(processusPoule == 1) {
				apoule = new OneByOne();
				//Poule p = new Poule(competitors, nbrPoules, apoule);
			}
			System.out.println(
					"Choisissez une méthode de selection :\n"
					+"1 : Firsts (select first competitor in each poule) \n" 
					+"2 : BestTwoFirsts (select 2 firsts competitors in each poule) \n" 
					+"3 : BestNCompetitors (select N competitors in each poule) \n" 
					+"4 : BestLastRandoms (EX: 4 poules, 4 compétiteurs chacune => 12 qualifiés(3 qualifiés de chaque poule)\n=> les 12 seront réduits en 8 en sélectionnant les meilleurs troisièmes."
					);
			int sM = sc.nextInt();
			
			if (sM == 1) {
				selection = new Firsts(nbrPoules, nbrPlayers);
			} else if (sM == 2) {
				selection = new BestTwoFirsts(nbrPoules, nbrPlayers);
			}
			else if (sM == 3) {
				System.out.println("Choisissez le nombre de compétiteurs qualifies de chaque poule :  ");
				int nbrq = sc.nextInt();
				selection = new BestNCompetitors(nbrPoules, nbrPlayers, nbrq);
			}else if (sM == 4) {
				System.out.println("Choisissez le nombre de compétiteurs qualifies de chaque poule :  ");
				int nbrq = sc.nextInt();
				selection = new BestLastRandoms(nbrPoules, nbrPlayers, nbrq);
			}
			master = new Master(competitors, selection, apoule);
			try {
				master.play();
			} catch (NumberOfCompetitorsNotExpected e) {
				System.out.println("The number of competitors is not expected to play master.\n");
			}
		}
		else {
			league.play();
			try {
				tournament.play();
				master.play();
			}catch(NotPowerOfTwoException e) {
				System.out.println("The number of competitors is not power of two, so the tournament cannot be played.\n");
			}catch(NumberOfCompetitorsNotExpected e) {
				System.out.println("The number of competitors is not expected to play master.\n");
			}
		}
		
	}
}




