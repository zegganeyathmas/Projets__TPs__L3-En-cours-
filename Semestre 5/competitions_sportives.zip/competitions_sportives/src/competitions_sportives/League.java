package competitions_sportives;
import java.util.*;
 
/**
 * class to play a league
 * @author yathmas
 * 
 */
public class League extends Competition{


	/**
	 * constructor
	 * @param competitors the list of competitors
	 *  
	 */
	public League(List<Competitor> competitors) {
		super(competitors);
		
	}
	
	
	/**
	 * this method manages the progress of the league
	 * @param competitors the list of competitors
	 */
	
	public void play(List<Competitor> competitors){
		int i,j; 

		for(i=0; i<=competitors.size()-1;i++){
			for(j=0;j<=competitors.size()-1;j++) {
				if(! competitors.get(i).equals(competitors.get(j))) {
					playMatch(competitors.get(i),competitors.get(j));
					//super.matchCommentsAndCotes(match);
				}
			} 
		} 
	} 
	

	
	
	/**
	 * this method display the winner of this league
	 */
	public void displayWinner() {
		Competitor winner = super.winnerOfTheCompetition();
		System.out.println("**** **** ****\n The winner of the League is : "+winner.toString()+" with : "+winner.getNbPoints()+" points.\n**** **** ****" );
	}
	
}
