package competitions_sportives;

import java.util.*;

import competitions_sportives.observable.CompetitionsEvent;
import competitions_sportives.observable.Cote;
import competitions_sportives.observable.MatchListener;
import competitions_sportives.observable.ScoreComment;
import competitions_sportives.util.MapUtil;

/**
 * Represents a Competition.
 * @author yathmas
 * @author elfakhouri
 * @version 1.0
 */
public abstract class Competition {

	/* list of the competitors */
	private final List<Competitor> competitors;
	protected int nbMatchPlayed;
	protected ArrayList<MatchListener> competitionsListener = new ArrayList<MatchListener>();
	
	/** 
	 * Constructor
	 * @param competitors the list of competitor's
	 */
	public Competition(List<Competitor> competitors) {
		this.competitors=competitors;
		nbMatchPlayed=0;
		this.addCompetitionsObservableListener(new ScoreComment());
		this.addCompetitionsObservableListener(new Cote());
	}
	
	/**
	 * Returns the list of competitors
	 * @return the list of competitors
	 */
	public List<Competitor> getCompetitors() {
		return competitors;
	}
	  
	/**
	 * allows the initialization of league or tournament competitions and also display the winner in these competitions
	 */
	public final void play() {
		this.play(competitors);
		this.displayClassement();
		this.displayWinner();
		this.displayCotes();
	}
	
	/**
	 * this method displays the ranking of a competition
	 */
	public void displayClassement() {
		System.out.println("\n**** Classement ****\n");
		for(Competitor c : this.ranking().keySet()) {
			System.out.println(c.getName()+" : "+c.getNbPoints()+" points.");
			
		}	
	}

	/**
	 * abstract method
	 */
	protected abstract void displayWinner();

	/**
	 * returns a competitor map ranked in ascending point order
	 * @return a competitor map ranked in ascending point order
	 */ 
	public Map<Competitor,Integer> ranking(){
		Map<Competitor,Integer> map = new HashMap<Competitor,Integer>();
		for(Competitor c : this.competitors) {
			map.put(c, c.getNbPoints());
		}
		map=MapUtil.sortByDescendingValue(map);
		return map;
	}
	
	/**
	 * @param competitors
	 */
	protected abstract void play(List<Competitor> competitors) ;
	
	/**
	 * this method plays a match match and returns the winner between the two competitors c1 and c2
	 * @param c1 first competitor
	 * @param c2 second competitor
	 * @return the winner between the two competitors c1 and c2
	 */
	public Competitor playMatch(Competitor c1, Competitor c2) {
		Match match = new Match(c1,c2);
		Competitor winner = match.winnerOfTheMatch(c1,c2);
		match.displayWinnerOfTheMatch(c1, c2, winner);
		this.matchCommentsAndCotes(match);
		winner.addPoints(1);
		this.incrementNbMatchPlayed();
		return winner;
	}
	
	/**
	 * this method display the odds of the competition
	 */
	public void displayCotes() {
		System.out.println("\nAffichage de cotes : \n");
		for(Competitor c : this.competitors) {
			System.out.println(c.getName()+" finit avec : "+ c.getCote()+" cotes.");
		}
	}
	
	/**
	 * this method add a object of type MatchListener to our list of MatchListener
	 * @param ce the matchListener to add
	 */
	public synchronized void addCompetitionsObservableListener(MatchListener ce) {
		if(this.getCompetitionsListener().contains(ce)) {
			return;
		}
		this.getCompetitionsListener().add(ce);
	}
	
	/**
	 * this method remove a object of type MatchListener to our list of MatchListener
	 * @param ce the matchListener to remove
	 */
	public synchronized void removeCompetitionsObservableListener(MatchListener ce) {
		if(this.getCompetitionsListener().contains(ce)) {
			this.getCompetitionsListener().remove(ce);
		}
		return;
	}
	
	/**
	 * this method allows us to react to a match of our competition
	 * @param match a match of our competitions
	 */
	public void matchCommentsAndCotes(Match match) {
		if(this.getCompetitionsListener().isEmpty()) {
			return;
		}
		CompetitionsEvent event = new CompetitionsEvent(match);
		for(MatchListener cl : this.getCompetitionsListener()) {
				cl.reactToMatch(event);
		}
	}

	/**
	 * returns the winner of the league
	 * @return the winner of the league
	 */ 
	public Competitor winnerOfTheCompetition() {
		Map<Competitor,Integer> map = this.ranking();
		Competitor winner = null;
		for(Competitor c : map.keySet()) {
			winner=c;
			break;
		}
		return winner;
	}
	
	/**
	 * this method returns a list that contains the reaction of the journalists on the competition as well as the different ratings given to each competitor after each match
	 */
	public List<MatchListener> getCompetitionsListener() {
		return competitionsListener;
	}
	
	
	/**
	 * @return number of match played
	 */
	public int getNbMatchPlayed() {
		return this.nbMatchPlayed;
	}
	
	/**
	 * this method increments the number of matches played in each competition
	 */
	public void incrementNbMatchPlayed() {
		this.nbMatchPlayed++;
	}
	
	/**
	 * displays the competitors ranked in ascending order of points
	 * @param map map of each competitor with the points that he accumulated
	 */
	public void displayRankedMap(Map<Competitor,Integer> map, String m) {
		System.out.println("\n***** Ranking de "+m+" *****");
		for(Competitor key : map.keySet()) {
			System.out.println(key +" - "+ map.get(key));
		}
	}

}
