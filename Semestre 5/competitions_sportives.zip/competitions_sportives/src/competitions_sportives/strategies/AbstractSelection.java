package competitions_sportives.strategies;

import java.util.List;

import competitions_sportives.Competitor;

public abstract class AbstractSelection{

	protected int nbPoules;
	protected int nbCompetitors;
	
	/**
	 * constructor
	 * @param nbPoules the number of groups in a Stage
	 * @param nbCompetitors the number of competitor in a group
	 */
	public AbstractSelection(int nbPoules, int nbCompetitors) {
		this.nbPoules = nbPoules;
		this.nbCompetitors = nbCompetitors;
	}
	
	public abstract List<Competitor> selectCompetitors(List<List<Competitor>> poules);
	
	public abstract int getNbQualifies();
	
	/**
	 * returns a number of Groups in a GroupStage
	 * @return a number of Groups in a GroupStage
	 */
	public int getNbPoules() {
		return this.nbPoules;
	}
	
	/**
	 * returns a number of competitors in a Group
	 * @return a number of competitors in a Group
	 */
	public int getNbCompetitors() {
		return this.nbCompetitors;
	}
	
	
	
}
