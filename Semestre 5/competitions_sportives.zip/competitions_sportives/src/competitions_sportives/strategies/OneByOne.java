package competitions_sportives.strategies;

import java.util.List;

import competitions_sportives.Competitor;
import competitions_sportives.util.NumberOfCompetitorsNotExpected;

public class OneByOne extends AbstractPoule {
	
	/**
	 * this method fills the hens with competitors
	 * @param competitors a list of the cometitors
	 * @nbPoules number of hens
	 */
	public List<List<Competitor>> partition(List<Competitor> competitors, int nbPoules) throws NumberOfCompetitorsNotExpected{
		List<List<Competitor>> poules = this.getPoules(nbPoules);
		int cpt=0;
		while(cpt < competitors.size()) {
			for(int i=0; i<nbPoules; i++) {
				if(cpt < competitors.size()) {
					poules.get(i).add(competitors.get(cpt));
					cpt++;
				}	
			}
		}
		return poules;
	}
}
