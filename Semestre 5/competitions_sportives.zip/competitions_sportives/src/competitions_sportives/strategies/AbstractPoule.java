package competitions_sportives.strategies;

import java.util.ArrayList;
import java.util.List;

import competitions_sportives.Competitor;
import competitions_sportives.util.NumberOfCompetitorsNotExpected;

public abstract class AbstractPoule {
	
	/**
	 * returns the list of hens we created
	 * @param nbPoules number of hens to make in our list
	 * @return the list of hens we created
	 */
	public List<List<Competitor>> getPoules(int nbPoules) {
		List<List<Competitor>> poules = new ArrayList<>();
		for(int i=0; i<nbPoules; i++) {
			List<Competitor> poule = new ArrayList<>();
			poules.add(poule);
		}
		return poules;
	}
	
	public abstract List<List<Competitor>> partition(List<Competitor> competitors, int nbPoules) throws NumberOfCompetitorsNotExpected;
	
}
