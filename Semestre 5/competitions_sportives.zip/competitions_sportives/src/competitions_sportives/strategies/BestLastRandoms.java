package competitions_sportives.strategies;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import competitions_sportives.Competitor;
import competitions_sportives.util.MapUtil;

public class BestLastRandoms extends BestNCompetitors {

	/**
	 * constructor
	 * @param nbPoules the number of groups in a Stage
	 * @param nbCompetitors the number of competitor in a group
	 * @param n number of competitor to select in each Group
	 */
	public BestLastRandoms(int nbPoules, int nbCompetitors, int n) {
		super(nbPoules,nbCompetitors,n);
	}
	
	/**
	 * returns a list containing the qualified competitors at the tournament phase
	 * @param poules a GroupStage
	 * @return a list containing the qualified competitors at the tournament phase
	 */
	public List<Competitor> selectCompetitors(List<List<Competitor>> poules) {
		List<Competitor> qualifies = new ArrayList<>();
		qualifies = super.selectCompetitors(poules);
        int i = qualifies.size();
        while(! isPowerOfTwo(i)) {
        	qualifies.remove(i-1);
        	i--;
        }
		return qualifies;
	}
	
	/**
	 * Returns true if x represents power of two and false if not
	 * @param x integer 
	 * @return true if x represents power of two and false if not
	 */
	public boolean isPowerOfTwo(int x) {
		return (x > 0) && (x & (x-1)) == 0;
	}

}