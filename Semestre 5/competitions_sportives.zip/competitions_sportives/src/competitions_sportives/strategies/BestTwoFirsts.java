package competitions_sportives.strategies;

import java.util.*;

import competitions_sportives.Competitor;

public class BestTwoFirsts extends BestNCompetitors {
	
	/**
	 * constructor
	 * @param nbPoules the number of groups in a Stage
	 * @param nbCompetitors the number of competitor in a group
	 */
	public BestTwoFirsts(int nbPoules, int nbCompetitors) {
		super(nbPoules,nbCompetitors, 2);
	}
	
	/**
	 * returns a list containing the first and second competitors of each group
	 * @param poules a GroupStage
	 * @return a list containing the first competitors of each group
	 */
	public List<Competitor> selectCompetitors(List<List<Competitor>> poules) {
		return super.selectCompetitors(poules);
	}
}
