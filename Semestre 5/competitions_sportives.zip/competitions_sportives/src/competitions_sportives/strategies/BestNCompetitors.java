package competitions_sportives.strategies;

import java.util.ArrayList;
import java.util.List;

import competitions_sportives.Competitor;

public class BestNCompetitors extends AbstractSelection{
	
	// le nombre de compétiteurs 
	protected int nbC;
	protected int nbQualifies;
	
	/**
	 * constructor
	 * @param nbPoules the number of groups in a Stage
	 * @param nbCompetitors the number of competitor in a group
	 * @param n number of competitor to select in each Group
	 */
	public BestNCompetitors(int nbPoules, int nbCompetitors, int n) {
		super(nbPoules,nbCompetitors);
		this.nbC = n;
	}

	/**
	 * returns a list containing n competitors of each group
	 * @param poules a GroupStage
	 * @return a list containing the first competitors of each group
	 */
	public List<Competitor> selectCompetitors(List<List<Competitor>> poules) {
		List<Competitor> qualifies = new ArrayList<>();
		for(int i = 0; i<this.getNbC(); i++) {
			for(List<Competitor> poule : poules){
					qualifies.add(poule.get(i));
			}
		}
		
		return qualifies;
	}
	
	/**
	 * returns a number of competitor to select in each Group
	 * @return a number of competitor to select in each Group
	 */
	protected int getNbC() {
		return nbC;
	}
	
	/**
	 * returns a number of qualified competitors to the next Stage
	 * @return a number of qualified competitors to the next Stage
	 */
	public int getNbQualifies() {
		return this.nbC * this.getNbPoules();
	}
	

}
