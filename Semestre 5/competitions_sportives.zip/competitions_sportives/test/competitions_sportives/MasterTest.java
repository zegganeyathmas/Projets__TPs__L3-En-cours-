package competitions_sportives;

import competitions_sportives.util.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.*;

public class MasterTest extends CompetitionTest {

	protected MockPoule p1;
	protected MockSelection s1;
	protected Master master;

	protected Competition createCompetition() {
		return new Master(this.competitors, s1, p1);
	}
	
	protected List<List<Competitor>> created;
	protected List<List<Competitor>> executed;
	protected List<Competitor> selected;
	protected List<Competitor> result;
	
	@BeforeEach
	public void init() {
		super.init();
		s1 = new MockSelection();
		p1 = new MockPoule();
		this.master = (Master) this.createCompetition();
	}
	
	
	@Test
	public void playMasterTest() throws NotPowerOfTwoException{
		assertEquals(0, this.competitors.get(0).getNbPoints());
		assertEquals(0, this.master.getLeagues().size());
		this.master.play();	
		assertEquals(this.s1.getNbPoules(), this.master.getLeagues().size());
	} 

	@Test
	public void createPoulesTest() {
		created = master.createPoules(competitors, this.s1.getNbPoules());
		assertTrue(created.get(0).contains(competitors.get(0)));
		assertEquals(created.get(0).get(0),competitors.get(0));
		assertEquals(created.get(0).get(1),competitors.get(2));
		assertEquals(created.get(1).get(0),competitors.get(1));
		assertEquals(created.get(1).get(1),competitors.get(3));
	}
	
	@Test
	public void executePoulesTest() {
		created = master.createPoules(competitors, this.s1.getNbPoules());
		executed = master.executePoules(created);
		assertTrue(executed.get(0).containsAll(created.get(0)));
		assertTrue(executed.get(1).containsAll(created.get(1)));
		assertTrue(executed.get(0).get(0).getNbPoints() >= executed.get(0).get(1).getNbPoints());
		assertTrue(executed.get(1).get(0).getNbPoints() >= executed.get(1).get(1).getNbPoints());
	}
	
	@Test
	public void phaseFinaleTest() {
		created = master.createPoules(competitors, this.s1.getNbPoules());
		executed = master.executePoules(created);
		selected = this.s1.selectCompetitors(executed);
		List<Competitor> finaliste = master.phaseFinale(selected);
		
		// les séléctionnés
		assertTrue(selected.get(0).getNbPoints() ==  executed.get(0).get(0).getNbPoints());
		assertSame(selected.get(1),  executed.get(1).get(0));
		assertTrue(selected.get(2).getNbPoints() ==  executed.get(0).get(1).getNbPoints());
		assertSame(selected.get(3),  executed.get(1).get(1));
		
		assertEquals(s1.getNbQualifies(), selected.size());
		assertEquals(this.s1.getNbQualifies(), finaliste.size());
		assertTrue(competitors.containsAll(finaliste));
		
		assertTrue(finaliste.get(0).getNbPoints() > 0); // le gagnant
		assertEquals(finaliste.get(0).getNbPoints(), Tournament.getWINNER().getNbPoints());// le gagnant
		assertEquals(0, finaliste.get(finaliste.size() - 1).getNbPoints());
		assertTrue(finaliste.get(0).getNbPoints() > finaliste.get(1).getNbPoints());
		
	}
	
}
