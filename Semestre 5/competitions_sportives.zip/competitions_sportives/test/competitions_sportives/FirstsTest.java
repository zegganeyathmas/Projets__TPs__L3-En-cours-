package competitions_sportives;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import competitions_sportives.strategies.*;

public class FirstsTest extends BeforeSelectionTest{

	private Firsts firsts;
	protected AbstractSelection createSelection() {
		return new Firsts(3,2); 
	}
	@BeforeEach
	public void init() {
		super.init();
		this.firsts = (Firsts) this.createSelection();
	}
	
	@Test
	public void selectCompetitorsNTest() {
		selected = firsts.selectCompetitors(this.executed); 
		assertSame(executed.get(0).get(0), selected.get(0));
		assertSame(executed.get(1).get(0), selected.get(1)); 
		assertSame(executed.get(2).get(0), selected.get(2));
		
		assertEquals(executed.get(0).get(0).getNbPoints(), selected.get(0).getNbPoints());
		assertEquals(executed.get(1).get(0).getNbPoints(), selected.get(1).getNbPoints()); 
		assertEquals(executed.get(2).get(0).getNbPoints(), selected.get(2).getNbPoints());
		
		assertFalse(selected.contains(executed.get(0).get(1)));
		assertFalse(selected.contains(executed.get(1).get(1)));
		assertFalse(selected.contains(executed.get(2).get(1)));
		
		assertEquals(this.firsts.getNbQualifies(), selected.size());
	}
	

}
