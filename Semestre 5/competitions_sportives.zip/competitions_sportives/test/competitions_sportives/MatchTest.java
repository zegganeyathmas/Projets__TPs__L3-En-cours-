package competitions_sportives;
import static org.junit.Assert.*;
import org.junit.*;

public class MatchTest {
	
	private Competitor c1;
	private Competitor c2;
	private Match match;
	private MockMatch mockMatch;
	private Competitor winner;
	
	@Before
	public void init() {
		this.c1 = new Competitor("bob");
		this.c2 = new Competitor("alice");
		this.match = new Match(this.c1,this.c2);
		this.mockMatch = new MockMatch();
		this.winner = mockMatch.winnerOfTheMatch(c1,c2);
	}
	
	@Test 
	public void winnerOfTheMatchTest() {  
		assertSame(c1,winner);
		assertFalse(c2.equals(winner));
	} 
	
	@Test
	public void getC1AndGetC2Test() {
		assertSame(this.c1,match.getC1());
		assertEquals(this.c2,match.getC2());
	}
	
}   
 