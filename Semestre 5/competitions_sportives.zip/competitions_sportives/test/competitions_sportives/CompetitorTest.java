package competitions_sportives;
import static org.junit.Assert.*;
import org.junit.Test;




public class CompetitorTest {
	
	private Competitor c1 ;
	private Competitor c2 ; 
	private Competitor c3 ; 
	
	@Test 
	public void competitorsMethodTest() {
		this.c1 = new Competitor("A");
		this.c2 = new Competitor("B"); 
		this.c3 = new Competitor("A");
		assertTrue(this.c1.equals(this.c3));
		assertTrue(this.c2.toString()=="B");
		assertEquals(this.c1.getNbPoints(),this.c2.getNbPoints());
		/*this.c1.setNbPoints(1);
		assertEquals(1,this.c1.getNbPoints());
		this.c2.setNbPoints(5);
		assertEquals(this.c2.getNbPoints(),5);*/
	}
}  
