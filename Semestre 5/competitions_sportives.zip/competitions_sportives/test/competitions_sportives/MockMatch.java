package competitions_sportives;
public class MockMatch extends Match{
	
	public MockMatch() {
		super(new Competitor("bob"),new Competitor("alice"));
	}
	
	public Competitor winnerOfTheMatch(Competitor c1, Competitor c2) { // ici le gagnant est : c1
		return c1;
	}
}
  