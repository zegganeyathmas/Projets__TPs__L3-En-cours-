package competitions_sportives;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import competitions_sportives.strategies.*;

public class BestLastRandomsTest extends BeforeSelectionTest{

	private BestLastRandoms bl;
	protected AbstractSelection createSelection() {
		return new BestLastRandoms(3,2,2); 
	}
	@BeforeEach
	public void init() {
		super.init();
		this.bl = (BestLastRandoms) this.createSelection();
	}
	
	@Test
	public void selectCompetitorsNTest() {
		selected = bl.selectCompetitors(this.executed);
		assertSame(executed.get(0).get(0), selected.get(0)); // le 1er compétiteur est le meme dans executed et result
		assertSame(executed.get(1).get(0), selected.get(1)); 
		assertSame(executed.get(2).get(0), selected.get(2)); 
		
		assertEquals(executed.get(0).get(0).getNbPoints(), selected.get(0).getNbPoints()); 
		assertEquals(executed.get(0).get(1).getNbPoints(), selected.get(3).getNbPoints());
		assertEquals(executed.get(2).get(0).getNbPoints(), selected.get(2).getNbPoints());
		
		assertFalse(selected.contains(executed.get(1).get(1)));
		assertFalse(selected.contains(executed.get(2).get(1)));
		
		assertEquals(4, selected.size());
	}
	

}
