package competitions_sportives;

import competitions_sportives.util.*;
import java.util.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TournamentTest extends CompetitionTest {

	public Competition createCompetition() {
		return new Tournament(super.competitors);
	}
	
	private Tournament tournament;
	
	@BeforeEach
	public void init() {
		super.init();
		//this.tournament = new Tournament(competitors);
		this.tournament = (Tournament) this.createCompetition();
	}
	  
	@Test
	public void playTournamentTest() {
		try {
		this.tournament.play(this.competitors);
		assertTrue(this.competitors.contains(Tournament.WINNER));
		}catch(NotPowerOfTwoException e) {
			e.getMessage();
		}
		
	} 
	
	
	@Test
	public void numberOfCompetitorsNotPowerOfTwoTest() {
		assertThrows(NotPowerOfTwoException.class,() -> {
			this.tournament.play(this.tournament.getCompetitors());
			assertEquals(this.tournament.getNbMatchPlayed(),this.competitors.size()-1);
		}
		);
	}
	
	@Test
	public void numberOfMatchPlayed() {
		List<Competitor> list = new ArrayList<>();
		list.add(c1); 
		list.add(c2);
		list.add(c3);
		list.add(c4);
		this.tournament.play(list);
		assertEquals(this.tournament.getNbMatchPlayed(), list.size()-1);			
	}

	@Test
	public void nbPointsChangedTest() {
		assertEquals(this.c2.getNbPoints(),this.c4.getNbPoints());
		assertEquals(this.c1.getNbPoints(),this.c3.getNbPoints());
		List<Competitor> l =new ArrayList<>();
		l.add(c1); l.add(c2);
		this.tournament.play(l);
		assertTrue(c1.getNbPoints() != c2.getNbPoints());
		assertEquals(1, this.tournament.getWINNER().getNbPoints());
	}
	


	
	@Test
	public void IsPowerOfTwoTest() {
		assertTrue(Tournament.isPowerOfTwo(8));
		assertFalse(Tournament.isPowerOfTwo(5));
	}
	
}
