package competitions_sportives;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import competitions_sportives.util.*;


public abstract class CompetitionTest {

	protected MockListener ml;
	protected List<Competitor> competitors = new ArrayList<>();
	protected Competitor c1 ;
	protected Competitor c2 ; 
	protected Competitor c3 ; 
	protected Competitor c4 ;
	protected Competitor c5 ;
	protected Competitor c6 ;
	
	protected abstract Competition createCompetition();

	 
	@BeforeEach
	public void init() {
		competitors = new ArrayList<>();
		c1 = new Competitor("A");
		c2 = new Competitor("B"); 
		c3 = new Competitor("C");
		c4 = new Competitor("D");
		c5 = new Competitor("E");
		c6 = new Competitor("F");
		competitors.add(c1);
		competitors.add(c2);
		competitors.add(c3);
		competitors.add(c4);
		competitors.add(c5);
		competitors.add(c6);
		this.ml = new MockListener();
	} 
	  
	@Test
	public void playTest() {
		try {
			int nb_points_init = this.competitors.get(0).getNbPoints(); // = 0
			assertTrue(nb_points_init == this.competitors.get(1).getNbPoints()); // ils ont tous 0 points
			assertEquals(0, this.createCompetition().getNbMatchPlayed());
			this.createCompetition().play();
		}catch(NotPowerOfTwoException e) {
			e.getMessage();
		}
		
	}  
	
	@Test
	public void playMatchTest() {	
		assertEquals(this.c2.getNbPoints(),this.c4.getNbPoints());
		assertEquals(this.c1.getNbPoints(),this.c3.getNbPoints());
		this.createCompetition().playMatch(c2, c4);
		assertTrue(this.c2.getNbPoints() != this.c4.getNbPoints());
		this.createCompetition().playMatch(c1, c3); 
		assertTrue(this.c1.getNbPoints() != this.c3.getNbPoints());	
	}
	
	@Test // les cotes après chaque match joué
	public void cotesChangedTest() {
		assertEquals(0, c1.getCote());
		assertEquals(0, c2.getCote());
		Competitor winner = this.createCompetition().playMatch(c1, c2); // playMatch fait appel à matchCommentsAndCotes
		assertTrue(winner.getCote() != 0);
		assertTrue(c1.getCote() != c2.getCote());
	}
	
	@Test // les cotes à la fin de chaque compétition
	public void cotesTotalTest() {
		for(Competitor c : competitors) {
			assertTrue(c.getCote() == 0);
		}
		try {
			this.createCompetition().play();
			Competitor winner = this.createCompetition().winnerOfTheCompetition();
			assertTrue(winner.getCote() < 0); // le gagnant a la plus petite cote
		}catch(NotPowerOfTwoException e) {
			e.getMessage();
		}
		
	}
	 
	@Test
	public void rankingTest() {
		c1.addPoints(2);
		c2.addPoints(1);
		c3.addPoints(4);
		c4.addPoints(0);
		c5.addPoints(3);
		c6.addPoints(5);
		Map<Competitor,Integer> map = this.createCompetition().ranking();
		List<Competitor> list = new ArrayList<>();
		for (Competitor c : map.keySet()) {
			list.add(c);
		}
		// liste obtenue : [c6,c3,c5,c1,c2,c4] ==> [E, C, F, A, B, D]
		assertEquals(6, list.size());
		assertTrue(list.get(1).equals(c3));
		assertTrue(list.get(3).equals(c1));
		assertTrue(list.get(4).equals(c2));
		assertTrue(list.get(5).equals(c4));
		assertTrue(list.get(2).equals(c5));
		assertTrue(list.get(0).equals(c6));
	}
	


}
