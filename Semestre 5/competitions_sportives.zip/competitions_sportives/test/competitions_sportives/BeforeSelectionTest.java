package competitions_sportives;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;

import competitions_sportives.strategies.AbstractPoule;
import competitions_sportives.strategies.AbstractSelection;
import competitions_sportives.strategies.OneByOne;

public abstract class BeforeSelectionTest {

	
	protected List<Competitor> competitors = new ArrayList<>();
	protected Competitor c1 ;
	protected Competitor c2 ; 
	protected Competitor c3 ; 
	protected Competitor c4 ;
	protected Competitor c5 ;
	protected Competitor c6 ;
	
	protected List<List<Competitor>> created;
	protected List<List<Competitor>> executed;
	protected List<Competitor> selected;
	protected Master master;
	protected AbstractPoule p1;
	protected AbstractSelection s1;
	protected abstract AbstractSelection createSelection();
	
	@BeforeEach
	public void init() {
		competitors = new ArrayList<>();
		selected = new ArrayList<>();
		c1 = new Competitor("A");
		c2 = new Competitor("B"); 
		c3 = new Competitor("C");
		c4 = new Competitor("D");
		c5 = new Competitor("E");
		c6 = new Competitor("F");
		competitors.add(c1);
		competitors.add(c2);
		competitors.add(c3);
		competitors.add(c4);
		competitors.add(c5);
		competitors.add(c6);
		this.p1 = new OneByOne();
		this.s1 = this.createSelection();
		this.master = new Master(competitors, s1, p1);
		created = master.createPoules(competitors, s1.getNbPoules()); 
		executed = master.executePoules(created);
	}
}
