package competitions_sportives;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Test;

import competitions_sportives.strategies.AbstractPoule;
import competitions_sportives.strategies.AbstractSelection;
import competitions_sportives.strategies.Firsts;
import competitions_sportives.strategies.OneByOne;

public class OneByOneTest extends MasterTest {

	protected AbstractPoule createPoules() {
		return new OneByOne();
	}

	
	protected AbstractSelection createSelection() {
		return new Firsts(2,2);
	}

	@Test
	public void partitionTest() {
		//List<List<Competitor>> part = p1.partition(competitors, 2);
		//assertTrue(part.contains(competitors.get(0)));
		/*assertEquals(part.get(0).get(0),competitors.get(0));
		assertEquals(part.get(0).get(1),competitors.get(2));
		assertEquals(part.get(1).get(0),competitors.get(1));
		assertEquals(part.get(1).get(1),competitors.get(3));*/
	}
}
