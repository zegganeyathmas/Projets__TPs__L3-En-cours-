package competitions_sportives;

import java.util.List;

import competitions_sportives.strategies.AbstractSelection;
import competitions_sportives.strategies.BestNCompetitors;

public class MockSelection extends AbstractSelection {
	
	private BestNCompetitors bn;
	
	public MockSelection() {
		super(2, 3);
		this.bn = new BestNCompetitors(2, 3, 2);
	}

	public int getNbQualifies() {
		return this.bn.getNbQualifies();
	}

	public List<Competitor> selectCompetitors(List<List<Competitor>> l) {
		return this.bn.selectCompetitors(l);
	}

}
