package competitions_sportives;

import competitions_sportives.observable.CompetitionsEvent;
import competitions_sportives.observable.Cote;
import competitions_sportives.observable.MatchListener;

public class MockListener implements MatchListener {

	private int cpt;
	private Cote c;
	
	public MockListener() {
		this.cpt = 0;
		this.c = new Cote();
	}
	
	public void reactToMatch(CompetitionsEvent ce) {
		this.c.reactToMatch(ce);
		this.cpt++;
	}

	public int getCpt() {
		return cpt;
	}
}
