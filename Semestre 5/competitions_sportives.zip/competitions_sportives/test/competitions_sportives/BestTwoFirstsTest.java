/*package competitions_sportives;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;

import competitions_sportives.strategies.*;

public class BestTwoFirstsTest extends BeforeSelectionTest{

	private BestTwoFirsts bestTwo;
	
	protected AbstractSelection createSelection() {
		return new BestTwoFirsts(3,2); 
	}
	@BeforeEach
	public void init() {
		super.init();
		this.bestTwo = (BestTwoFirsts) this.createSelection();
	}

	
	@Test
	public void selectCompetitorsTest() {
		selected = bestTwo.selectCompetitors(this.executed); 
		System.out.println(selected);
		assertSame(executed.get(0).get(0), selected.get(0));
		assertSame(executed.get(1).get(0), selected.get(1)); 
		assertSame(executed.get(2).get(0), selected.get(2));
		
		assertEquals(executed.get(0).get(0).getNbPoints(), selected.get(0).getNbPoints());
		assertEquals(executed.get(1).get(1).getNbPoints(), selected.get(4).getNbPoints()); 
		assertEquals(executed.get(2).get(0).getNbPoints(), selected.get(2).getNbPoints());
		
		assertTrue(selected.get(0).getNbPoints() >= selected.get(1).getNbPoints());
		assertTrue(selected.contains(executed.get(0).get(1)));
		assertTrue(selected.contains(executed.get(1).get(1)));
		assertTrue(selected.contains(executed.get(2).get(1)));
		
		assertEquals(this.bestTwo.getNbQualifies(), selected.size());
	}

}*/
