package competitions_sportives;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.*;

import competitions_sportives.strategies.*;


public class BestNCompetitorsTest extends BeforeSelectionTest{


	private BestNCompetitors bn;

	protected AbstractSelection createSelection() {
		// dans cet exemple de test N=2 (BestTwoFirsts).   N = nombre de compétiteurs qui seront sélectionnés de chaque poule
		return new BestNCompetitors(3, 2, 2); // poule1:[A,D]   poule2:[B,E]  poule3:[C,F] 
	}
	
	@BeforeEach
	public void init() {
		super.init();
		this.bn = (BestNCompetitors) this.createSelection();
	}
	
	@Test
	public void selectCompetitorsNTest() {
		selected = bn.selectCompetitors(this.executed); 
		assertSame(executed.get(0).get(0), selected.get(0));
		assertSame(executed.get(1).get(0), selected.get(1)); 
		assertSame(executed.get(2).get(0), selected.get(2));
		
		assertEquals(executed.get(0).get(0).getNbPoints(), selected.get(0).getNbPoints());
		assertEquals(executed.get(1).get(1).getNbPoints(), selected.get(4).getNbPoints()); 
		assertEquals(executed.get(2).get(0).getNbPoints(), selected.get(2).getNbPoints());
		
		assertTrue(selected.get(0).getNbPoints() >= selected.get(1).getNbPoints());
		assertTrue(selected.contains(executed.get(0).get(1)));
		assertTrue(selected.contains(executed.get(1).get(1)));
		assertTrue(selected.contains(executed.get(2).get(1)));
		
		assertEquals(this.bn.getNbQualifies(), selected.size());
	}

	

}
