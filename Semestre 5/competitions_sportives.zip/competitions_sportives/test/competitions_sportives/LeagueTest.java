package competitions_sportives;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.*;

public class LeagueTest extends CompetitionTest {
	
	public Competition createCompetition() {
		return new League(this.competitors);
	}
	
	private League league;
	
	@BeforeEach
	public void init() {
		super.init();
		//this.league = new League(competitors);
		this.league = (League)this.createCompetition();
	}
	 
	@Test
	public void playLeagueTest() {
		league.play(league.getCompetitors());
		Map<Competitor,Integer> map = league.ranking();
		List<Competitor> list = new ArrayList<>();
		for(Competitor c : map.keySet()) {
			list.add(c);
		}
		assertTrue(list.get(0).getNbPoints() >= list.get(1).getNbPoints());
		assertFalse(list.get(0).getNbPoints() == 0);
		assertEquals(30,league.getNbMatchPlayed());
	}  

	
	@Test
	public void winnerOfTheLeagueTest() {
		this.league.play(this.league.getCompetitors());
		Competitor winner = this.league.winnerOfTheCompetition();
		assertTrue(winner.getNbPoints() != 0);
	}
	
	@Test
	public void numberOfMatchPlayed() {
		this.league.play(this.league.getCompetitors());
		assertEquals(this.league.getNbMatchPlayed(),this.competitors.size()*(this.competitors.size()-1));
	}
	

}
