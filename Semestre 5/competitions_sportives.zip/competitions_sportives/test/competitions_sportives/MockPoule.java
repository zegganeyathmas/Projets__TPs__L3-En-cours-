package competitions_sportives;

import java.util.List;

import competitions_sportives.strategies.AbstractPoule;
import competitions_sportives.strategies.OneByOne;
import competitions_sportives.util.NumberOfCompetitorsNotExpected;

public class MockPoule extends AbstractPoule {

	private OneByOne on;
	
	public MockPoule() {
		super();
		this.on = new OneByOne();
	}
	
	
	public List<List<Competitor>> partition(List<Competitor> competitors, int nbPoules)
			throws NumberOfCompetitorsNotExpected {
	
		return this.on.partition(competitors, nbPoules);
	}

}
