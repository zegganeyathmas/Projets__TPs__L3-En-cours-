# Competitions_sportives
## Membres du Binome :
**ZEGGANE Yathmas**  

**El FAKHOURI Yasser**  

# Livrable 1 --> 14 directories, 39 files
 

## 1- Introduction sur le sujet du projet
- Ce projet represente un championnat de competitions sportives, dont les competiteurs peuvent participer a plusieurs competitions tels que: *League* et *Tournament*. Les competiteurs et le type de competitions dont ils y participent sont modelises par des classes.
## 2- How TO :
### A- Recover the repository of the project
- git clone git@gitlab-etu.fil.univ-lille.fr:yathmas.zeggane.etu/competitions_sportives.git
### B- Generate Docstring
```La documentation sera redirige vers le repertoire doc qui sera cree en executant dans un shell :```
- javadoc -sourcepath src -d docs competitions_sportives  

**Ou :**
``` 
make docs
```
### C- Compilation / Execution des sources
**Depuis la racine du projet or dans le dossier competitions_sportives:**
#### a- Compilation du projet
- javac -sourcepath src -d classes ./src/competitions_sportives/main/MainCompetition.java  

**Ou :**
- make  

    -- NB : on peut ne pas preciser le nom de la premiere regle du Makefile qui est ici **cls** puisque c'est la premiere regle, c'est la regle invoque par **make** sans argument.
#### b- Execution du projet
- java -classpath classes competitions_sportives.main.MainCompetition  

**Ou :**
- make 

#### c- Compilation des Tests
**Compilation :**    
> RQ : si vous etes sous linux, remplacez le ; par :


-  javac -d classes -sourcepath src -cp ".;lib/junit-platform-console-standalone-1.9.1.jar" test/competitions_sportives/*.java
 
#### d- Execution des Tests
**Execution :**
- java -jar lib/junit-platform-console-standalone-1.9.1.jar -cp classes --select-package competitions_sportives  


**Couverture de code**
![Coverage](labels/Coverage.PNG)



### D- Jar executable 
``` Dans la racine du projet : ```
#### a- Creation du jar
*Apres avoir compiler le projet (commande precisee ci-dessus), on execute la commande suivante pour la creation du JAR :*  

- jar -cvfm essai.jar MANIFEST.MF.txt classes/competitions_sportives/*.class classes/competitions_sportives/main/*.class classes/competitions_sportives/util/*.class
#### b- Visualisation du jar
- jar tvf jar/comp_spor.jar
#### d- Execution du jar
- java -jar jar/comp_spor.jar  

**Ou :**
```Dans la racine du projet, l'exécution de la commande suivante permettra de créer un JAR et le lancer :```  
- make jar


## 3-1- Sailent code
- La methode abstraite **playMatch** de **Competition** est implemente dans **League** de façon à incrementer les points du vainqueur, par contre dans **Tournament** elle est implemente differemment or sans changer le nombre de points du vainqueur car dans un tournoi on s'interesse aux tours gagnes par un competitor et pas a ses points.
- Une methode abstraite **CreateCompetition()** est utilise dans les methodes de test de **CompetitionTest**, elle est implemente dans les sous-classes **LeagueTest** et **TournamentTest** et eventuellement d'autres type de competitions.

## 3-2- Conception parts
- Lien d'heritage **Competition** avec les différentes competitions **League** et **Tournament**:
![heritage](uml/heritage.png)
- Lien d'heritage entre **CompetitionTest** avec **LeagueTest** et **TournamentTest**
- Lien d'héritage entre **Match** et **MockMatch**

## 3-3- Principles used
- **Open-Closed principle :**Si on souhaite ajouter une competition, il suffit de preciser le lien d'heritage entre elle et la classe Competition.```
- **Single Responsability principle :**
League gère les leagues, tournament gère les tournois ...  

-La methode play de Competition ne fait que derouler une league et un tournoi, League à son tour dispose d'une methode play qui deroule les matchs de la league, et de meme pour tournament deroule le tournoi avec sa methode play.

## 3-4- Design Patterns
- **Template Method** : la méthode *play()* de *Competition* est une Template Method, elle fait appel aux méthodes abstraites qui sont définis obligatoirement dans les sous-classe (*League*, *Tournament*...) en les invoquant à **this** qui représente l'objet de type compétition.
```
public final void play() {
		this.play(competitors);
		this.displayWinner();
	}
```
# Livrable 2 --> 15 directories, 70 files
- **Couverture de code**
![Coverage_L2](labels/Coverage_L2.PNG)
## 3-1
- L'attribut **AbstractSelection s** dans *Master* permet d'appeler la méthode de séléction de competiteurs souhaitée.
- L'attribut **AbstractPoule p** dans *Master* représente le processus de création des poules. 
- Les méthodes de sélection sont représentés chacune dans une classe qui hérite la classe abstraite AbstractSelection afin d'implanter la façon dont on sélectionne les compétiteurs qualifiés à la phase finale:
``` 
- Firsts --> sélectionne le premier de chaque poule.
- TwoFirsts --> sélectionne les 2 premiers de chaque poules.
- BestLastRandoms --> exemple: 4 poules, 4 compétiteurs chacune, on choisit d'en faire qualifier 3, donc 12 compétiteurs qualifiés (12 n'est pas une puissance de 2), donc cette classe élimine les derniers compétiteurs sélectionnés selon leur points dans l'ordre croissant.
- BestNCompetitors --> sélectionne les N premiers compétiteurs de chaque poule. 
``` 

- **BestNCompetitors** est à priori la seule classe de sélection qui hérite de **AbstractSelection* car elle est basique, elle sélectionne N de chaque poule qui sont forcément qualifié.
- AbstractSelection a 2 autres méthodes autre que *selectCompetitors* qui sont *getNbPoules()* et *getNbCompetitors()*, ces deux méthodes sont communes pour les classes qui représentent les méthodes de sélection des compétiteurs qui sont qualifiés à la phase finale, par exemple en ayant un *BestTwoFirsts* à (4 poules, 3 compétiteurs chacune) --> *getNbPoules()* vaut 4, *getNbCompetitors()* vaut 3.
- Les classes de sélection ne redéfinissent pas totalement les méthodes de sélections, elle sont basées sur lien d'héritage entre les classes de sélection, donc pratiquement chaque classe de sélection comportera un **super.selectCompetitors** comme : **Firsts**, **BestTwoFirsts**, **BestLastRandoms** avec **BestNCompetitors**
- Le stratégie de la création de poules est passé en paramètre à **Poule**
## 3-2
- Lien d'héritage entre **BestNCompetitors** et la classe abstraite  **AbstractSelection**. 
- ![bestN](uml/bestN.png)
- Lien d'héritage entre **Les classes de sélection**.
- ![Héritage des classes de sélection](uml/selectionMethods.png)
## 3-4
- **AbstractSelection** : le lien d'héritage entre *AbstractSelection* et les classes qui représentent les méthodes de séléction des compétiteurs pour la phase finale. Le pattron *Strategy* a été utilisé car plusieurs méthodes de séléction des compétiteurs existent pour un meme but qui est de les faire qualifier à la phase finale à partir de la phase de poules.
![AbstractSelection](uml/AbstractSelection.PNG)


# Livrable 3 --> 18 directories, 82 files
- **Couverture de code**
![Coverage_L3](labels/Coverage_L3.PNG)

## 3-1
- test des méthodes de sélections.
- Utilisation du design pattern **Observable** dans le but de manipuler les cotes des compétiteurs après chaque match, ainsi que de donner des commentaires.
- La méthode *matchCommentsAndCotes* de *Competition* gère l'action des listeners à l'aide de son paramètre *Match* qui permettra de donner le gagnant.
- Il y a 2 listeners, un pour la gestion des cotes, l'autre pour les commentaires, chacun implémente la **reactToMatch** de sa façon.
## 3-4
- Implemntation des listeners de l'interface des listeners, et passage en paramètre de *reactToMatch* de cette interface un *CompetitionEvent* qui a pour paramètre l'observable qui  est ici *Competition*:
	- ![observable](labels/observable.png)
- En plus de *AbstractSelection*, on a la strategie de la création de poules à l'aide de *AbstractPoule*:
	- ![AbstractPoule](labels/AbstractPoule.PNG)
